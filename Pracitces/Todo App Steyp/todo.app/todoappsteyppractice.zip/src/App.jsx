// import logo from "./logo.svg";
import "./App.css";
import Todo from "./Components/ToDo_Component";

function App() {
  return <Todo />;
}

export default App;
