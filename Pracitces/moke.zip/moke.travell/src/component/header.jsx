import React from "react";

export default function Header() {
  return (
    <header>
      <h1>
        m<span>ok</span>e.
      </h1>
      <button>Login</button>
    </header>
  );
}
