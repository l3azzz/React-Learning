import React from "react";
import Body from "./body";

export default function Home() {
  return (
    <>
      <Body />
    </>
  );
}
